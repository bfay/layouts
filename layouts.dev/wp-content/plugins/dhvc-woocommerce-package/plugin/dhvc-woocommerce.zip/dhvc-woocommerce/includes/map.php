<?php
vc_map ( array (
		"name" => __ ( "WOO Products", DHVC_WOO ),
		"base" => "dhvc_woo_products",
		"category" => __ ( "WooComerce", DHVC_WOO ),
		"icon" => "icon-dhvc-woo-product",
		"params" => dhvc_woo_params()
) );